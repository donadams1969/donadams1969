# Valor Forensic Vault — AES Edition

Tamper-evident, append-only forensic vault with **encryption-at-rest (AES-256-GCM)**,
a **hash-chained ledger**, and **CI-friendly integrity checks**.

## Quick start

```bash
# 0) Set a strong passphrase (not in shell history; prefer a password manager)
export VAULT_PASSPHRASE='correct horse battery staple'
# Optional: override KDF iterations (default 210000)
export VAULT_KDF_ITER=210000

# 1) Initialize
./scripts/init_vault.sh vault

# 2) Add evidence (plaintext is securely deleted after encryption)
VAULT_DIR=vault ./scripts/add_evidence.sh /path/to/file "optional label"

# 3) Verify integrity
# - auto: decrypts and checks plaintext if key present, otherwise checks ciphertext
# - plaintext: requires key; verifies original SHA-256
# - ciphertext: keyless CI mode; verifies encrypted blobs
VAULT_DIR=vault VERIFY_MODE=auto ./scripts/check_integrity.sh

# 4) Decrypt a file when needed
VAULT_DIR=vault ./scripts/decrypt_evidence.sh enc/<uid>-<name>.enc /secure/output/path
```

## How it works

- **AES-256-GCM** with **PBKDF2** (iterations configurable via `VAULT_KDF_ITER`).
- Each ledger row stores: plaintext SHA-256, ciphertext SHA-256, algorithm, KDF params, and a **chained `entry_hash`**.
- The **ledger is append-only** and tamper-evident: each entry's hash depends on the previous entry's hash + content.
- CI can run **ciphertext-only** verification without secrets. Local/full verification decrypts and compares plaintext hash.

## Key management

- Provide the passphrase via `VAULT_PASSPHRASE`. Do **not** hardcode it or commit it.
- Consider wrapping usage with an OS keyring, 1Password, or gopass script.
- Key rotation: decrypt and re-encrypt each artifact with a new passphrase and record a `rotate` event (ask for a helper script).

## Security notes

- This design layers **cryptographic confidentiality** (AES-GCM) with **cryptographic integrity** (hash-chain + GCM tag).
- For maximum assurance, store the ledger offsite as well (e.g., WORM storage) and mirror ciphertexts to multiple locations.
