
const hre = require("hardhat");

async function main() {
  const Badge = await hre.ethers.getContractFactory("VALORBadgeNFT");
  const badge = await Badge.deploy();
  await badge.deployed();
  console.log("VALORBadgeNFT deployed to:", badge.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
