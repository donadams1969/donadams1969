
const hre = require("hardhat");

async function main() {
  const nftAddress = "0xYour_NFT_Contract_Address_Here"; // Replace before running
  const Token = await hre.ethers.getContractFactory("UnshortableVBLKToken");
  const token = await Token.deploy(nftAddress);
  await token.deployed();
  console.log("UnshortableVBLKToken deployed to:", token.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
