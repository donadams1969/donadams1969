# 🧬 VBLKx + VALORBadgeNFT – Anti-Short Token + Identity Protocol  
This branch deploys:

- ✅ `VALORBadgeNFT.sol`: ERC721-based NFT badge for verified contributors
- ✅ `UnshortableVBLKToken.sol`: Short-proof ERC-20 token that gates access by NFT

---

## 🧱 Architecture

| Component              | Role |
|------------------------|------|
| `VALORBadgeNFT`        | Minted to contributors to verify access |
| `UnshortableVBLKToken` | Enforces NFT ownership or whitelist for transfers |
| DAO Integration (v1.1) | Controls whitelist + treasury vault     |

---

## 🚀 Deployment Flow

```bash
# 1. Deploy NFT badge
npx hardhat run scripts/deployNFT.js --network sepolia

# 2. Deploy VBLKx token with NFT address
npx hardhat run scripts/deployToken.js --network sepolia
```

---

## 🔐 Authored By

**Donny Adams**  
Founder of That’s Edutainment, LLC  
Creator of VALORCHAIN & VALOR AI+  
Official Portal: [www.18fu.cash](https://www.18fu.cash)
