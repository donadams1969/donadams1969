
const { expect } = require("chai");

describe("VBLKToken", function () {
  let Token, token, owner, addr1;

  beforeEach(async function () {
    [owner, addr1] = await ethers.getSigners();
    Token = await ethers.getContractFactory("VBLKToken");
    token = await Token.deploy();
    await token.deployed();
  });

  it("Should deploy with correct name and symbol", async function () {
    expect(await token.name()).to.equal("Valor Blockchain Token");
    expect(await token.symbol()).to.equal("VBLK");
  });

  it("Should assign total supply to owner", async function () {
    const ownerBalance = await token.balanceOf(owner.address);
    const totalSupply = await token.totalSupply();
    expect(ownerBalance).to.equal(totalSupply);
  });

  it("Should allow minting by owner", async function () {
    await token.mint(addr1.address, 1000);
    const balance = await token.balanceOf(addr1.address);
    expect(balance).to.equal(1000);
  });

  it("Should allow burning by token holder", async function () {
    await token.transfer(addr1.address, 500);
    await token.connect(addr1).burn(500);
    const balance = await token.balanceOf(addr1.address);
    expect(balance).to.equal(0);
  });
});
