# VALOR PQ Attestation — Signing Guide

We recommend **dual-signing** each anchor message:
- **Operational:** Ed25519 (widely supported)
- **PQ Assurance:** Dilithium2/3 (NIST PQC)

## Message to sign

Use your EIP-712 typed data digest (same bytes for both signatures).
Store artifacts in `pq_attestation.json` following `pq_attestation.schema.json`.

## Ed25519 (example with `openssl` + `age` keys or libsodium-based tools)

```bash
# pk/sk generation depends on your stack; below is illustrative.
# Sign the digest (hex) and base64-encode the signature.
```

## Dilithium (liboqs)

```bash
# Install liboqs (or oqs-provider for OpenSSL 3)
# Sign the same EIP-712 digest bytes (hex) and base64-encode the signature.
```

Include both signatures and corresponding public keys (base64) in the JSON.
