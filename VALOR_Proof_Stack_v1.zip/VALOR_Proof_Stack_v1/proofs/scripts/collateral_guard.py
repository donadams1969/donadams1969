#!/usr/bin/env python3
import json, argparse

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("snapshot_json")
    ap.add_argument("--alpha", type=float, required=True)
    ap.add_argument("--posterior", type=float, required=True)
    args = ap.parse_args()

    js = json.load(open(args.snapshot_json, "r", encoding="utf-8"))
    R = float(js["reserves_usd"]); L = float(js["liabilities_usd"])
    posterior = float(js.get("posterior_risk_ok", 0.0))

    cond1 = (R / L) >= args.alpha
    cond2 = posterior >= args.posterior
    ok = cond1 and cond2

    print(json.dumps({
        "ok": ok,
        "ratio": R / L if L else None,
        "need_alpha": args.alpha,
        "need_posterior": args.posterior,
        "posterior": posterior
    }, indent=2))
    exit(0 if ok else 5)

if __name__ == "__main__":
    main()
