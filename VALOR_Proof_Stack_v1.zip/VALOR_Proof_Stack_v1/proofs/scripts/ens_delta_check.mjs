import https from "https";
const ENS = process.env.ENS_TXT_API;

function get(u){ 
  return new Promise((res,rej)=>https.get(u, r => {
    let b=""; r.on('data', d=> b+=d);
    r.on('end', ()=> res(b));
    r.on('error', rej);
  }));
}

const last = JSON.parse(process.argv[2]||"{}");
if(!ENS){ console.error("Set ENS_TXT_API to a TXT JSON endpoint"); process.exit(2); }

const raw = await get(ENS);
let now;
try { now = JSON.parse(raw); } catch { now = {}; }

// Accept both DNS JSON or a raw JSON map; fallback
let txtCid = null;
if(now?.Answer){
  for(const a of now.Answer){
    if(a.data && a.data.includes("valoraiplus.dashboard.cid")){
      // TXT like: "valoraiplus.dashboard.cid=ipfs://..."
      const m = a.data.match(/valoraiplus\.dashboard\.cid=([^"]+)/);
      if(m){ txtCid = m[1]; break; }
    }
  }
} else if (now["valoraiplus.dashboard.cid"]) {
  txtCid = now["valoraiplus.dashboard.cid"];
}

if(!txtCid){
  console.log("No TXT cid found"); process.exit(1);
}

if(txtCid === last["valoraiplus.dashboard.cid"]) {
  console.log("ENS delta OK (no conflict)");
} else {
  console.log("ENS updated to new CID:", txtCid);
}
