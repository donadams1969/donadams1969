#!/usr/bin/env python3
import json, sys, argparse, hashlib, os
CANON = bytes.fromhex("0A0A0A0A")

def sha256(b): return hashlib.sha256(b).digest()

def merkle_root(frames):
    nodes = [sha256(CANON + bytes.fromhex(x["sha256"])) for x in frames]
    if not nodes:
        return "0x" + "00"*32
    while len(nodes) > 1:
        nxt = []
        for i in range(0, len(nodes), 2):
            a = nodes[i]
            b = nodes[i+1] if i+1 < len(nodes) else nodes[i]  # repeat-last
            nxt.append(sha256(a + b))
        nodes = nxt
    return "0x" + nodes[0].hex()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("checksums_json")
    ap.add_argument("--out", default="proofs/index.json")
    ap.add_argument("--root", default="proofs/merkle_root.txt")
    args = ap.parse_args()

    js = json.load(open(args.checksums_json, "r", encoding="utf-8"))
    frames = js["entries"]
    root = merkle_root(frames)

    out = {
        "canon": "0x0A0A0A0A",
        "hash_algo": js.get("hash_algo", "sha256"),
        "num_leaves": len(frames),
        "merkle_root": root,
        "leaves": frames,
    }
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    with open(args.root, "w", encoding="utf-8") as f:
        f.write(root + "\n")
    print(root)

if __name__ == "__main__":
    main()
