#!/usr/bin/env python3
import json, sys, argparse, hashlib

CANON = bytes.fromhex("0A0A0A0A")
def sha256(b): return hashlib.sha256(b).digest()

def merkle_root(frames):
    nodes = [sha256(CANON + bytes.fromhex(x["sha256"])) for x in frames]
    if not nodes:
        return "0x" + "00"*32
    while len(nodes) > 1:
        nxt = []
        for i in range(0, len(nodes), 2):
            a = nodes[i]
            b = nodes[i+1] if i+1 < len(nodes) else nodes[i]
            nxt.append(sha256(a + b))
        nodes = nxt
    return "0x" + nodes[0].hex()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("checksums_json")
    ap.add_argument("expected_root_file")
    args = ap.parse_args()
    frames = json.load(open(args.checksums_json))["entries"]
    got = merkle_root(frames)
    exp = open(args.expected_root_file).read().strip()
    ok = (got.lower() == exp.lower())
    print(json.dumps({"expected": exp, "computed": got, "ok": ok}, indent=2))
    sys.exit(0 if ok else 2)

if __name__ == "__main__":
    main()
