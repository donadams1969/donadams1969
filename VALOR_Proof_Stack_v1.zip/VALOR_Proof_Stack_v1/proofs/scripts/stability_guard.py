#!/usr/bin/env python3
import csv, argparse, json

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("telemetry_csv")
    ap.add_argument("--tmax", type=float, required=True, help="Max safe device temp (C)")
    ap.add_argument("--k", type=float, required=True, help="Cooling conductance")
    ap.add_argument("--cth", type=float, required=True, help="Thermal capacitance")
    ap.add_argument("--tamb", type=float, default=25.0)
    args = ap.parse_args()

    violations = []
    for row in csv.DictReader(open(args.telemetry_csv, newline="")):
        t = float(row["temp_c"])
        p = float(row["power_w"])
        # Cooling budget C = k*(Tmax - Tamb)
        C = args.k * (args.tmax - args.tamb)
        if p > C or t > args.tmax:
            violations.append({"timestamp": row["timestamp"], "temp_c": t, "power_w": p, "C_budget": C})

    ok = (len(violations) == 0)
    print(json.dumps({"ok": ok, "violations": violations[:10], "num_violations": len(violations)}, indent=2))
    exit(0 if ok else 4)

if __name__ == "__main__":
    main()
