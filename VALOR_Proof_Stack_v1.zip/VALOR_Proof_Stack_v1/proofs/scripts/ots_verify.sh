#!/usr/bin/env bash
# Requires: OpenTimestamps 'ots' CLI
set -euo pipefail
if [ $# -lt 1 ]; then
  echo "Usage: $0 file.ots"; exit 1
fi
ots verify "$1" && echo "OTS verified" || (echo "OTS verify failed"; exit 7)
