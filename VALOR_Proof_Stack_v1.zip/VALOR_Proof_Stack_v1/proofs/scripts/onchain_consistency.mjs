// Minimal on-chain invariant check: RootRegistry(proofRoot) ↔ Card.cardData(tokenId).proofRoot
// Usage: set env RPC_URL, ROOT_REGISTRY, CARD_ADDR, TOKEN_ID, PROOF_ROOT_HEX
import { ethers } from "ethers";

const RPC_URL = process.env.RPC_URL;
const ROOT_REGISTRY = process.env.ROOT_REGISTRY;
const CARD_ADDR = process.env.CARD_ADDR;
const TOKEN_ID = process.env.TOKEN_ID;
const PROOF_ROOT_HEX = (process.env.PROOF_ROOT_HEX||"").toLowerCase();

const provider = new ethers.JsonRpcProvider(RPC_URL);

const regAbi = [
  "function get(bytes32) view returns (uint256 tokenId, address card)"
];
const cardAbi = [
  "function cardData(uint256) view returns (bytes32 proofRoot)"
];

const reg = new ethers.Contract(ROOT_REGISTRY, regAbi, provider);
const card = new ethers.Contract(CARD_ADDR, cardAbi, provider);

const [tokenId, cardAddr] = await reg.get(PROOF_ROOT_HEX);
const cd = await card.cardData(TOKEN_ID);

const ok = (String(tokenId) === String(TOKEN_ID)) && 
           (cardAddr.toLowerCase() === CARD_ADDR.toLowerCase()) &&
           (cd.proofRoot.toLowerCase() === PROOF_ROOT_HEX);

console.log(JSON.stringify({ ok, tokenId: String(tokenId), cardAddr, proofRoot: cd.proofRoot }, null, 2));
process.exit(ok ? 0 : 6);
