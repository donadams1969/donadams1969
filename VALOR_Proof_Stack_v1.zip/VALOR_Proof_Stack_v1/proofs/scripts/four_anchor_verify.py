#!/usr/bin/env python3
import json, sys

CANON = "0x0A0A0A0A"

def main():
    if len(sys.argv) < 2:
        print("Usage: four_anchor_verify.py cloud.codex.json"); sys.exit(1)
    data = json.load(open(sys.argv[1], "r", encoding="utf-8"))
    ok = True
    reasons = []

    if not data.get("parent_cid","").startswith("ipfs://"):
        ok = False; reasons.append("CID missing or not ipfs://")
    if not data.get("ots_file","").endswith(".ots"):
        ok = False; reasons.append("OTS file missing or wrong extension")
    mr = data.get("merkle_root","")
    if not (mr.startswith("0x") and len(mr)==66):
        ok = False; reasons.append("Merkle root not 0x-prefixed 32-byte hex")
    if not data.get("evidence_anchor",{}).get("txHash","").startswith("0x"):
        ok = False; reasons.append("Evidence anchor txHash missing")
    snap = data.get("ens_snapshot",{})
    if snap.get("valoraiplus.dashboard.cid") != data.get("parent_cid"):
        ok = False; reasons.append("ENS TXT cid != parent_cid")

    out = {"canon": CANON, "ok": ok, "reasons": reasons}
    print(json.dumps(out, indent=2))
    sys.exit(0 if ok else 3)

if __name__ == "__main__":
    main()
