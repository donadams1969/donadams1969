# VALOR Proof Stack v1

_Audit & verification kit for Four-Anchor Equivalence, PQ attestations, Lyapunov thermal guard,
on-chain registry consistency, collateral safety, and ZK Merkle proof blueprint._

**Build time:** 2025-09-03T02:17:40.374068Z

## What’s inside

```
proofs/
├── README.md
├── tla/VALORAIPLUS_FourAnchor_V0.tla
├── tla/VALORAIPLUS_FourAnchor_V0.cfg
├── scripts/merkle_build.py
├── scripts/merkle_verify.py
├── scripts/four_anchor_verify.py
├── scripts/stability_guard.py
├── scripts/collateral_guard.py
├── scripts/ens_delta_check.mjs
├── scripts/onchain_consistency.mjs
├── scripts/ots_verify.sh
├── artifacts/checksums_multi.sample.json
├── artifacts/cloud.codex.sample.json
├── telemetry/thermal_log.sample.csv
├── compliance/collateral_snapshot.sample.json
├── pq/pq_attestation.schema.json
├── pq/pq_attestation.example.json
├── pq/signing_guide.md
├── zk/merkle_blueprint.md
├── zk/circom/merkle_sha256.circom
└── solidity/
    ├── MerkleVerifier.sol
    ├── MerkleAnchor.sol
    └── RootRegistryInvariant.t.sol  (Foundry-style invariant test skeleton)
```

## Quickstart

1) **Python ≥ 3.9**: Merkle + guards

```bash
cd proofs
python3 scripts/merkle_build.py artifacts/checksums_multi.sample.json --out proofs/index.json --root proofs/merkle_root.txt
python3 scripts/merkle_verify.py artifacts/checksums_multi.sample.json proofs/merkle_root.txt
python3 scripts/four_anchor_verify.py artifacts/cloud.codex.sample.json
python3 scripts/stability_guard.py telemetry/thermal_log.sample.csv --tmax 85 --k 3.0 --cth 20.0
python3 scripts/collateral_guard.py compliance/collateral_snapshot.sample.json --alpha 1.5 --posterior 0.995
```

2) **ENS delta** (Node ≥ 18)

```bash
export ENS_TXT_API="https://dns-json.cloudflare-dns.com/dns-query?name=_valoraiplus.yourname.eth&type=TXT"
node scripts/ens_delta_check.mjs artifacts/cloud.codex.sample.json
```

3) **OpenTimestamps** (requires `ots` cli)

```bash
bash scripts/ots_verify.sh path/to/your.ots
```

4) **On-chain check** (Node + `ethers`)

```bash
# Set RPC + contract addresses in env before running
node scripts/onchain_consistency.mjs
```

5) **TLA+**

Open `tla/VALORAIPLUS_FourAnchor_V0.tla` in TLC and model-check with the provided `.cfg`.
This proves the pipeline cannot claim `ok=TRUE` without all five anchors present.

6) **ZK Merkle (blueprint)**

See `zk/merkle_blueprint.md` and `zk/circom/merkle_sha256.circom` for a portable circuit sketch.
Use Circom/SnarkJS or Halo2 to implement fully.

## Canon / Domain Separation

**Canon v2 = 0x0A0A0A0A**

Leaves are framed as `SHA256( CanonV2 || digest_bytes )`. Internal nodes use `SHA256(left || right)`.
Odd nodes **duplicate the last** (repeat-last) for determinism.

## Policy knobs (edit safely)

- Thermal: `T_max`, `k` (cooling conductance), `C_th` (thermal capacitance)
- Collateral: `alpha` (reserve ratio), `posterior` (risk threshold)
- ENS: TXT record key `valoraiplus.dashboard.cid`
- EIP-712 domain/type: edit in your Anchor contract & client if needed

---

© 2025 That’s Edutainment, LLC — MIT license for this kit’s code (see source headers).
