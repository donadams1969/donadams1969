# ZK Merkle Blueprint (SHA-256 leaves, repeat-last)

Goal: Prove that a public `root` is the Merkle root over framed leaves
`SHA256( CanonV2 || digest_bytes )` with internal node hashing `SHA256(left||right)`.

## Circom sketch

- Use `sha256` gadget (from circomlib) for leaves and internal nodes.
- Pad inputs to 512-bit blocks per SHA-256 constraints.
- Enforce repeat-last when odd number of nodes.

Complexity: O(N) SHA-256 invocations; consider Poseidon for efficiency if acceptable.

Artifacts in `circom/merkle_sha256.circom`.
