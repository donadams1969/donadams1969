pragma circom 2.1.0;

// NOTE: This is a sketch; wire into circomlib's SHA256 component in your build.
// Proves: root == Merkle(leaves) with repeat-last and CanonV2 framing.

template MerkleSHA256(nLeaves) {
    // Signal declarations
    signal input leaves[nLeaves][32]; // raw digest bytes per leaf (32 bytes)
    signal input root[32];            // expected root (32 bytes)
    // ... connect to SHA256 gadgets and tree wiring ...
    // For brevity, we omit the full gadget code in this skeleton.
    // Ensure framing CanonV2 = 0x0A0A0A0A is prepended at leaves.
    // Ensure odd-level duplication.
    // Constrain final computed root == input root.
    // signal output ok; set to 1 if satisfied.
}
component main = MerkleSHA256(2);
