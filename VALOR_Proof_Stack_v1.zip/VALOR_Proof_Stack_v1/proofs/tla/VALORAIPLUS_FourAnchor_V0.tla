---------------------------- MODULE VALORAIPLUS_FourAnchor_V0 ----------------------------
EXTENDS Naturals, Sequences

(*************************************************************************)
(* Variables                                                             *)
(*************************************************************************)
VARIABLES cid, ots, merkle, anchorTx, ensTxt, ok

Init ==
  /\ cid = ""
  /\ ots = ""
  /\ merkle = ""
  /\ anchorTx = ""
  /\ ensTxt = ""
  /\ ok = FALSE

HashStep ==
  /\ merkle' # "" /\ merkle' \in STRING
  /\ UNCHANGED << cid, ots, anchorTx, ensTxt, ok >>

CidStep ==
  /\ cid' # "" /\ cid' \in STRING
  /\ UNCHANGED << merkle, ots, anchorTx, ensTxt, ok >>

OtsStep ==
  /\ ots' # "" /\ ots' \in STRING
  /\ UNCHANGED << cid, merkle, anchorTx, ensTxt, ok >>

AnchorStep ==
  /\ anchorTx' # "" /\ anchorTx' \in STRING
  /\ UNCHANGED << cid, merkle, ots, ensTxt, ok >>

EnsStep ==
  /\ ensTxt' # "" /\ ensTxt' \in STRING
  /\ UNCHANGED << cid, merkle, ots, anchorTx, ok >>

Verify ==
  /\ cid # "" /\ ots # "" /\ merkle # "" /\ anchorTx # "" /\ ensTxt # ""
  /\ ok' = TRUE
  /\ UNCHANGED << cid, merkle, ots, anchorTx, ensTxt >>

Next == HashStep \/ CidStep \/ OtsStep \/ AnchorStep \/ EnsStep \/ Verify

Spec == Init /\ [][Next]_<<cid, ots, merkle, anchorTx, ensTxt, ok>>

Invariant_FourAnchors ==
  ok => /\ cid # "" /\ ots # "" /\ merkle # "" /\ anchorTx # "" /\ ensTxt # ""

THEOREM Spec => []Invariant_FourAnchors
=============================================================================
