// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

library MerkleVerifier {
    /// @notice Verify a path using sha256(left||right) with repeat-last convention.
    function verify(bytes32 root, bytes32 leaf, bytes32[] memory path, bool[] memory isLeft) internal pure returns (bool) {
        bytes32 h = leaf;
        for (uint i = 0; i < path.length; i++) {
            if (isLeft[i]) {
                h = sha256(abi.encodePacked(path[i], h));
            } else {
                h = sha256(abi.encodePacked(h, path[i]));
            }
        }
        return h == root;
    }
}
