// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract MerkleAnchor {
    bytes32 public merkleRoot;
    event RootUpdated(bytes32 indexed oldRoot, bytes32 indexed newRoot, address indexed by);

    function setRoot(bytes32 newRoot) external {
        emit RootUpdated(merkleRoot, newRoot, msg.sender);
        merkleRoot = newRoot;
    }
}
