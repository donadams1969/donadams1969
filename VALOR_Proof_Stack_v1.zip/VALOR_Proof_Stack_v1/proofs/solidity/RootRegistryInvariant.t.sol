// SPDX-License-Identifier: MIT
// Foundry-style invariant skeleton
pragma solidity ^0.8.20;

interface IRootRegistry {
    function get(bytes32 proofRoot) external view returns (uint256 tokenId, address card);
}

interface ICard {
    function cardData(uint256 tokenId) external view returns (bytes32 proofRoot);
}

contract RootRegistryInvariant {
    IRootRegistry constant reg = IRootRegistry(address(0x0000000000000000000000000000000000000000));
    ICard constant card = ICard(address(0x0000000000000000000000000000000000000000));
    uint256 constant TOKEN_ID = 0;

    function invariant_RootMatchesCard() external view {
        // set with cheatcodes in your Foundry test before running invariants
        bytes32 proofRoot = bytes32(0);
        (uint256 tId, address cAddr) = reg.get(proofRoot);
        require(tId == TOKEN_ID, "tokenId mismatch");
        require(cAddr == address(card), "card address mismatch");
        (bytes32 pr) = card.cardData(TOKEN_ID);
        require(pr == proofRoot, "card.proofRoot mismatch");
    }
}
