# VALORAI Fiat Starter

A minimal, real-world starter kit to add **Fiat Transfers** to VALORAI+/VESL stacks.

## What you get
- FastAPI backend with `/payments` routes
- Provider adapter interface + Stripe/Wise/Plaid stubs
- Risk engine + approval routing
- Postgres SQL migrations (append-only ledger chain)
- Orchestration skeleton (Celery) for VESL-0001
- Tiny React admin screens (Create Transfer, Approvals, Detail)
- Docker compose for local dev (api + postgres + redis)

## Quick start

```bash
cp .env.example .env
docker compose up --build
# API: http://localhost:8080/docs
# Frontend (static dev server): open frontend/index.html
```
> NOTE: Stubs only — wire real keys and flows per provider docs.

## Directory
- `backend/` FastAPI app
- `orchestration/` Celery workers + workflow
- `migrations/` SQL for Postgres
- `frontend/` small React UI scaffold
- `scripts/` helper scripts

## Security
- RBAC hooks, step-up MFA placeholders
- SHA-256 hash chain in `ledger_entries`
- Webhook signature verification stubs

## License
MIT (sample only; use at your own risk).
