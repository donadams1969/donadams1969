#!/bin/bash
npx hardhat compile
mkdir -p build
cp -r artifacts build/
ipfs add -r build
