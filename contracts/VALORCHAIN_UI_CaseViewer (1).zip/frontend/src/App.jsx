import './App.css';
import { useState } from 'react';
import WalletConnect from './components/WalletConnect';
import AddCaseForm from './components/AddCaseForm';
import ViewCase from './components/ViewCase';

function App() {
  const [signer, setSigner] = useState(null);

  return (
    <div className="App p-6 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">⚖️ VALOR Registry Codex</h1>
      <WalletConnect onConnect={setSigner} />
      {signer && (
        <>
          <AddCaseForm signer={signer} />
          <ViewCase signer={signer} />
        </>
      )}
    </div>
  );
}

export default App;
