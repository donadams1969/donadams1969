import { useState } from 'react';
import { getContract } from '../contract';
import { keccak256, toUtf8Bytes } from 'ethers';

export default function ViewCase({ signer }) {
  const [cid, setCid] = useState('');
  const [result, setResult] = useState(null);

  async function fetchCase() {
    try {
      const caseId = keccak256(toUtf8Bytes(cid));
      const contract = await getContract(signer);
      const caseData = await contract.cases(caseId);
      if (!caseData.exists) {
        setResult('❌ No case found.');
      } else {
        setResult(`✅ Case found:
  - Case ID: ${caseData.caseId}
  - Submitter: ${caseData.submitter}
  - Timestamp: ${new Date(caseData.timestamp * 1000).toLocaleString()}
  - Document Hash: ${caseData.documentHash}`);
      }
    } catch (err) {
      setResult('❌ Error: ' + err.message);
    }
  }

  return (
    <div className="p-4 border rounded-xl shadow mt-4">
      <h2 className="text-lg font-semibold mb-2">View Case</h2>
      <input
        type="text"
        className="border p-2 w-full mb-2"
        placeholder="Enter Document Hash (CID)"
        value={cid}
        onChange={(e) => setCid(e.target.value)}
      />
      <button onClick={fetchCase} className="bg-gray-800 text-white px-4 py-2 rounded-lg">
        Lookup Case
      </button>
      {result && <pre className="mt-3 text-sm whitespace-pre-wrap">{result}</pre>}
    </div>
  );
}
