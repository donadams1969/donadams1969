# VALORCHAIN IPFS Package

This package contains metadata and sample configuration for deploying the VALORCHAIN file dashboard on IPFS using Web3.Storage.

## Files
- metadata.json: Contains file index entries
- README.md: This documentation
