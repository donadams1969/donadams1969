import { ethers } from 'ethers';
import contractABI from '../artifacts/contracts/ValorRegistryCodex.sol/ValorRegistryCodex.json';

const CONTRACT_ADDRESS = 'YOUR_DEPLOYED_CONTRACT_ADDRESS_HERE';

export async function getContract(signerOrProvider) {
  return new ethers.Contract(CONTRACT_ADDRESS, contractABI.abi, signerOrProvider);
}
