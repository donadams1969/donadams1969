import { Web3Storage } from 'web3.storage';

const token = 'YOUR_WEB3_STORAGE_API_TOKEN';

export function makeStorageClient() {
  return new Web3Storage({ token });
}

export async function storeFiles(files) {
  const client = makeStorageClient();
  const cid = await client.put(files);
  return cid;
}
