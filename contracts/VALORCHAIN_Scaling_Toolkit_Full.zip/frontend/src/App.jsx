import './App.css';
import { getEnsGateway } from './ensLink';
import { storeFiles } from './pinToWeb3Storage';

function App() {
  async function handleUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    const cid = await storeFiles([file]);
    const link = getEnsGateway(cid);
    alert('Pinned! ENS Link: ' + link);
  }

  return (
    <div className="App">
      <h1>⚖️ VALOR Registry Codex</h1>
      <p>Anchor your legal data with ENS and IPFS.</p>
      <input type="file" onChange={handleUpload} />
    </div>
  );
}

export default App;
