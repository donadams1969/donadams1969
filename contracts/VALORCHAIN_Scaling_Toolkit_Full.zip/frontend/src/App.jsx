import './App.css';

function App() {
  return (
    <div className="App">
      <h1>⚖️ VALOR Registry Codex</h1>
      <p>Immutable legal record anchoring powered by Ethereum + IPFS.</p>
    </div>
  );
}

export default App;
