const { Web3Storage, File } = require('web3.storage');
const fs = require('fs');
const path = require('path');

function getFiles(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  return entries.flatMap(entry => {
    const fullPath = path.join(dir, entry.name);
    return entry.isDirectory() ? getFiles(fullPath) : [new File([fs.readFileSync(fullPath)], path.relative('dist', fullPath))];
  });
}

async function main() {
  const token = 'YOUR_WEB3_STORAGE_TOKEN_HERE';
  const client = new Web3Storage({ token });
  const files = getFiles('./dist');
  const cid = await client.put(files);
  console.log(`✅ Deployed! View at: https://${cid}.ipfs.dweb.link`);
}

main().catch(console.error);
