export function getEnsGateway(cid) {
  return `https://${cid}.ipfs.dweb.link`;
}
