import { ethers } from 'ethers';
import contractABI from '../artifacts/contracts/ValorRegistryCodex.sol/ValorRegistryCodex.json';

const CONTRACT_ADDRESS = '0xYourDeployedContractAddress'; // Replace with actual deployed address

export async function getContract(signerOrProvider) {
  return new ethers.Contract(CONTRACT_ADDRESS, contractABI.abi, signerOrProvider);
}
