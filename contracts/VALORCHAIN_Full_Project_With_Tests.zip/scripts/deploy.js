// scripts/deploy.js
const { ethers } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with the account:", deployer.address);

  // Deploy VBLKToken
  const VBLKToken = await ethers.getContractFactory("VBLKToken");
  const vblk = await VBLKToken.deploy();
  await vblk.deployed();
  console.log("VBLKToken deployed to:", vblk.address);

  // Deploy DBLKVault
  const approvers = [deployer.address];
  const approvalsRequired = 1;
  const DBLKVault = await ethers.getContractFactory("DBLKVault");
  const vault = await DBLKVault.deploy(vblk.address, approvers, approvalsRequired);
  await vault.deployed();
  console.log("DBLKVault deployed to:", vault.address);

  // Deploy VACNAccess
  const accessThreshold = ethers.utils.parseUnits("100", 18);
  const VACNAccess = await ethers.getContractFactory("VACNAccess");
  const vacn = await VACNAccess.deploy(vblk.address, accessThreshold);
  await vacn.deployed();
  console.log("VACNAccess deployed to:", vacn.address);

  // Deploy JAXXMicro
  const dummyNFT = ethers.constants.AddressZero; // Replace with actual NFT address
  const rewardRate = 10;
  const JAXXMicro = await ethers.getContractFactory("JAXXMicro");
  const jaxx = await JAXXMicro.deploy(dummyNFT, rewardRate);
  await jaxx.deployed();
  console.log("JAXXMicro deployed to:", jaxx.address);
}

main()
  .then(() => process.exit(0))
  .catch(error => {
    console.error(error);
    process.exit(1);
  });
