export function Button({ children, onClick, className = '', variant = '' }) {
  const base = 'px-4 py-2 rounded-lg text-white font-medium';
  const style = variant === 'outline'
    ? 'bg-white border text-gray-800 border-gray-300'
    : 'bg-blue-600 hover:bg-blue-700';
  return (
    <button onClick={onClick} className={`${base} ${style} ${className}`}>
      {children}
    </button>
  );
}
