import { useState, useEffect } from "react";
import { ethers } from "ethers";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function DaoDashboard() {
  const [account, setAccount] = useState(null);
  const [proposal, setProposal] = useState("");
  const [proposals, setProposals] = useState([]);

  useEffect(() => {
    async function loadWallet() {
      if (window.ethereum) {
        const provider = new ethers.BrowserProvider(window.ethereum);
        const accounts = await provider.send("eth_requestAccounts", []);
        setAccount(accounts[0]);
      }
    }
    loadWallet();
  }, []);

  const submitProposal = () => {
    if (!proposal) return;
    setProposals((prev) => [...prev, { id: prev.length + 1, text: proposal }]);
    setProposal("");
  };

  return (
    <div className="p-4 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">VALORCHAIN DAO Dashboard</h1>
      <p className="text-sm text-gray-500 mb-4">
        Connected wallet: <span className="font-mono">{account}</span>
      </p>

      <Card className="mb-6">
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold mb-2">Submit a Proposal</h2>
          <Input
            type="text"
            placeholder="Enter proposal title..."
            value={proposal}
            onChange={(e) => setProposal(e.target.value)}
          />
          <Button onClick={submitProposal} className="mt-2">
            Submit
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {proposals.map((p) => (
          <Card key={p.id}>
            <CardContent className="p-4">
              <h3 className="font-semibold">Proposal #{p.id}</h3>
              <p className="text-sm text-gray-700">{p.text}</p>
              <div className="mt-2 space-x-2">
                <Button variant="outline">Vote Yes</Button>
                <Button variant="outline">Vote No</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
