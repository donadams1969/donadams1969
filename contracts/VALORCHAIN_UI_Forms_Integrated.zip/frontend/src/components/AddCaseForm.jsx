import { useState } from 'react';
import { getContract } from '../contract';
import { keccak256, toUtf8Bytes } from 'ethers';

export default function AddCaseForm({ signer }) {
  const [docHash, setDocHash] = useState('');
  const [message, setMessage] = useState('');

  async function submitCase() {
    try {
      const caseId = keccak256(toUtf8Bytes(docHash));
      const contract = await getContract(signer);
      const tx = await contract.addCase(caseId, docHash);
      await tx.wait();
      setMessage('✅ Case added: ' + caseId);
    } catch (err) {
      setMessage('❌ Error: ' + err.message);
    }
  }

  return (
    <div className="p-4 border rounded-xl shadow">
      <h2 className="text-lg font-semibold mb-2">Add Case</h2>
      <input
        type="text"
        className="border p-2 w-full mb-2"
        placeholder="Enter Document Hash (IPFS CID)"
        value={docHash}
        onChange={(e) => setDocHash(e.target.value)}
      />
      <button onClick={submitCase} className="bg-black text-white px-4 py-2 rounded-lg">
        Submit Case
      </button>
      {message && <p className="mt-2 text-sm">{message}</p>}
    </div>
  );
}
