import { useState, useEffect } from 'react';
import { ethers } from 'ethers';

export default function WalletConnect({ onConnect }) {
  const [address, setAddress] = useState(null);

  async function connectWallet() {
    if (!window.ethereum) return alert('MetaMask is required.');
    const provider = new ethers.BrowserProvider(window.ethereum);
    const accounts = await provider.send('eth_requestAccounts', []);
    setAddress(accounts[0]);
    const signer = await provider.getSigner();
    onConnect(signer);
  }

  useEffect(() => {
    if (window.ethereum && window.ethereum.selectedAddress) {
      connectWallet();
    }
  }, []);

  return (
    <div className="p-4">
      {address ? (
        <p className="text-sm text-green-600">Connected: {address}</p>
      ) : (
        <button onClick={connectWallet} className="bg-blue-600 text-white px-4 py-2 rounded-lg">
          Connect Wallet
        </button>
      )}
    </div>
  );
}
