# 🏷️ ENS + IPFS Verification Badges

These badges validate that your VALOR Registry Codex entries are correctly anchored to decentralized storage and human-readable domains.

---

## ✅ Example Entry Badge (Replace with your actual values)

![ENS](https://img.shields.io/badge/ENS-valorchain.eth-purple?logo=ethereum)
![IPFS](https://img.shields.io/badge/IPFS-Deployed-green?logo=ipfs)
[![Access](https://img.shields.io/badge/View-dweb.link-blue)](https://bafybeiexamplecid.ipfs.dweb.link)

---

## 🧠 Add Your Own

1. Deploy your frontend via Web3.Storage or IPFS CLI
2. Get the CID and map it to ENS in your registrar
3. Replace these fields in your Markdown:

```markdown
![ENS](https://img.shields.io/badge/ENS-yourname.eth-purple?logo=ethereum)
![IPFS](https://img.shields.io/badge/IPFS-Deployed-green?logo=ipfs)
[![Access](https://img.shields.io/badge/View-dweb.link-blue)](https://bafybeiyourcid.ipfs.dweb.link)
```

---

> Anchoring legal truth in decentralized space — one hash at a time.
