# 📦 VBLK Token – Change Log  
_Tracking versioned releases of the VALORCHAIN utility token system_

---

## [v1.0.0-next] – Initial Smart Contract Deployment  
**Date:** 2025-05-09  
**Author:** Donny Adams

### ✅ Added
- ✅ `VBLKToken.sol`: ERC-20 contract with mint/burn and 100M supply
- ✅ `deploy.js`: Hardhat script for Sepolia & Polygon Mumbai networks
- ✅ `VBLKToken.test.js`: Complete unit test suite using Chai and Ethers
- ✅ GitHub Actions CI (`test.yml`) auto-runs on push to `main` or `next`
- ✅ `hardhat.config.js`: multi-network support (localhost, sepolia, mumbai)
- ✅ `index.md`: GitHub Pages landing portal for https://www.18fu.cash
- ✅ Metadata sealing via SHA256 and OpenTimestamps logic

### 🔐 Security
- Token is owner-mintable only
- Burnable only by token holders
- No admin upgradeability (immutable)

### 🌐 Infrastructure
- Fully compatible with GitHub Pages, IPFS metadata, and NFT badge layers
- Future-ready for DAO governance, NFT issuance, and Treasury logic

---

## 🔭 Coming Soon (v1.1.0)
- `DAO.sol`: Snapshot + voting integration
- `VaultMint.sol`: Contributor badge registry with NFT issuance
- `AuditLog.sol`: Public chain-of-custody for compliance logs

> Each release is timestamped, verified, and VALORCHAIN sealed.
