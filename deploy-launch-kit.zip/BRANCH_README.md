# 🌐 VBLK Token – Next Branch: Smart Contract Deployment

![Branch: next](https://img.shields.io/badge/Branch-next-blue?style=flat-square)  
![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)  
![Status](https://img.shields.io/github/workflow/status/DonAdams1969/VBLK_Token/Run%20Hardhat%20Tests?label=CI%20Status&style=flat-square)

---

## 🧱 Overview

This branch (`next`) contains the full development stack for the **VBLKToken**, the ERC-20 utility token anchoring the VALORCHAIN ecosystem.  
Built by **Donny Adams**, this token powers the AI-verified, OpenTimestamps-anchored compliance architecture deployed through [18fu.cash](https://www.18fu.cash).

---

## ✅ Features in This Branch

| Component        | Description                                 |
|------------------|---------------------------------------------|
| `VBLKToken.sol`  | ERC-20 token with mint/burn and 100M supply |
| `deploy.js`      | Hardhat deploy script                       |
| `VBLKToken.test.js` | Unit tests with Chai + Ethers.js       |
| `CI/CD`          | GitHub Actions pipeline (auto-tests)        |
| `hardhat.config.js` | Dual-network config (Sepolia, Mumbai)  |

---

## 🧪 How to Run Locally

1. Clone repo and switch to `next`:
```bash
git clone https://github.com/DonAdams1969/VBLK_Token.git
cd VBLK_Token
git checkout next
```

2. Install dependencies:
```bash
npm install
```

3. Run tests:
```bash
npx hardhat test
```

4. Deploy to Sepolia:
```bash
npx hardhat run scripts/deploy.js --network sepolia
```

---

## 🌐 Deployment Metadata

| Network       | Chain ID | Explorer Link              |
|---------------|----------|----------------------------|
| Sepolia       | 11155111 | [sepolia.etherscan.io](https://sepolia.etherscan.io) |
| Polygon Mumbai| 80001    | [mumbai.polygonscan.com](https://mumbai.polygonscan.com) |

> Deployment addresses will be updated after contract is verified.

---

## 🛡️ Authored By

**Donny Adams**  
Founder, That’s Edutainment, LLC  
Architect of VALORCHAIN + VALOR AI+

GitHub: [@DonAdams1969](https://github.com/DonAdams1969)  
Live Portal: [18fu.cash](https://www.18fu.cash)

---

## 🧬 Legal & Ethics Tag

This code is protected under the **VALORSHIELD Compliance Doctrine**, timestamped, sealed, and designated for veteran-first regulatory protection.

---
