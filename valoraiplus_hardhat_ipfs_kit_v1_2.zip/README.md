# VALOR AI+ Aegis — Hardhat + IPFS Auto-Pin Kit (v1.2)

**One-command deploy → tokenlist.json → notarize (CustodyRoot) → IPFS pin → case-manager CIDs.**

## 🔧 What you get
- **Hardhat** project with `ValorToken.sol` (OZ ERC20) ready to deploy.
- **Auto tokenlist emitter** — writes `tokenlist.json` after deploy (Uniswap-style list).
- **Notarization** — computes **CustodyRoot** using `H = SHA-256 * VALORAIPLUS` domain separation:
  \[ CustodyRoot = \operatorname{SHA256}( NOTARY\_ID \;||\; '|' \;|| \text{join}(\text{sorted} ( \{SweepRoot\} \cup \{JobRoots\} \cup \{Receipts\} ))) \]
- **IPFS pinning** — pins `tokenlist.json`, `receipts/receipt.json`, and logo to one or more **Kubo HTTP** endpoints.
- **Case-manager drop** — writes live CIDs to `case-manager/ingest_cids.json` and optionally POSTs to your webhook.
- **Branding** — Valor AI+ logo pinned and referenced in the tokenlist `logoURI`.

## 🚀 Quickstart
```bash
cp .env.template .env
# edit .env with RPC_URL_SEPOLIA, PRIVATE_KEY, IPFS_API_URLS (default: http://127.0.0.1:5001)
npm install

# Deploy + emit + notarize + pin + push CIDs (default Sepolia config from .env)
npx hardhat deployAndPin --network sepolia   --name "Valor AI+ Token"   --symbol "VALX"   --supply "1000000000"   --decimals 18   --logo assets/brand/valor_ai_plus_logo.svg
```

### Environment
- `IPFS_API_URLS`: Comma-separated list of Kubo HTTP base URLs *(without `/api/v0`)* — e.g. `http://127.0.0.1:5001,https://ipfs.my-node:5001`
- `PIN_RECEIPT=1`: Auto-pin `receipts/receipt.json` after notarization.
- `CASE_MANAGER_WEBHOOK`: If set, the task POSTs `{ brand, action, network, deployment, cids, timestamp }`.
- `NOTARY_ID`: Domain separation tag (default: `VALORAIPLUS`).

### Receipts
- **ETH** receipt automatically generated on deploy (`receipts/eth_receipt.json`).
- Optionally add your own: `receipts/btc_receipt.json`, `receipts/valorchain_receipt.json`:
  ```json
  { "type":"BTC", "network":"mainnet", "txid":"<your-txid>" }
  { "type":"VALORCHAIN", "network":"mainnet", "txid":"<your-anchor-or-hash>" }
  ```
- Put `SweepRoot` (string) in `receipts/sweep_root.txt` and an array of `JobRoots` in `receipts/job_roots.json`.
- Run `npm run notarize` or let the **task** do it; output at `receipts/receipt.json`.

### Tokenlist
- Generated to `tokenlist.json` using the latest file in `deployments/*`.
- If the logo was pinned in the same run, its CID is used for `logoURI` (via `receipts/pinning_report.json`).

## 🧩 Under the hood
- **Task** `deployAndPin`: deploys ERC20 → saves ETH receipt → emits tokenlist → notarizes → pins → posts CIDs.
- **CustodyRoot** preimage: `NOTARY_ID + '|' + join(sorted(unique({SweepRoot} ∪ {JobRoots} ∪ {Receipts.txid})), '|')`.
- **IPFS pinning**: direct **Kubo** HTTP `/api/v0/add?pin=true&cid-version=1` with streaming `multipart/form-data`.

## 🛡️ Branding
- Minimal **Valor AI+** SVG included at `assets/brand/valor_ai_plus_logo.svg`.
- Replace with your official asset and keep the same path, or supply `--logo`.

## ✅ Sanity commands
```bash
# Compile
npm run build

# Emit tokenlist after a previous deployment
npm run emit:tokenlist

# Recompute notarization (CustodyRoot)
npm run notarize

# Re-pin files (to all endpoints in IPFS_API_URLS)
npm run pin:files
```

---

© That’s Edutainment, LLC — VALOR AI+®. All rights reserved.


> **Security Note:** ASCII banners were removed to prevent glyph/kerning spoofing (e.g., “FALOR”).


## 🛡️ ValorAiAegis+ (Accelerated Security)
- **Strict codemark**: `SPECIAL_CODE=VALORAIPLUS` (NOTARY_ID must be VALORAIPLUS)
- **Alias ban**: `ValorToken` is **forbidden** (removed from codebase). Sentinel & SEC Guard fail builds if found.
- **Loop hardening**: `npm run loop` launches **ValorAiLoop+** to notarize+pin on any receipt change.
- **CI gate**: see `.github/workflows/valorai_aegis_guard.yml` (blocks PRs with banned terms or failing SEC checks).
