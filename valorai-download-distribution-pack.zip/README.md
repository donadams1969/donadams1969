# VALORAI Download Distribution Pack

Turn any ZIP into a mirrored, verified public download with one-liners.

## Quick start

```bash
make all FILE=valorai-fiat-starter.zip
```

This will:
- build `downloads/valorai-fiat-starter.html` and `.json`
- push to codex + skroll mirrors and verify hashes
- generate a QR code and a tiny SHA badge

## GitHub

- Tag a release to auto-create a draft with mirrors + hash:
  - tag format: `fiat-starter-YYYY.MM.DD`
- Nightly CI checks the mirrors for this file.
