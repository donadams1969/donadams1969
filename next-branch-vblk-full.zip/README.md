# 🧠 VBLKToken – VALORCHAIN Utility Token  
### ERC-20 Smart Contract for VBLK ("vBlock") Token

![VALORCHAIN Verified](https://img.shields.io/badge/VALORCHAIN-Verified-green?style=for-the-badge)  
![MIT License](https://img.shields.io/badge/License-MIT-blue?style=for-the-badge)  
![Deployed to](https://img.shields.io/badge/Status-Ready%20For%20Deployment-orange?style=for-the-badge)

---

## 🔐 Overview

This smart contract defines the **VBLK Token**, the official utility token for the **VALORCHAIN ecosystem**, minted and governed by **Donny Adams**.

---

## ⚙️ Key Features

- ✅ ERC-20 Compliant  
- ✅ Mintable (by Owner only)  
- ✅ Burnable (by users)  
- ✅ 18 decimals, 100M initial supply  
- ✅ GitHub/Gateway reference: `www.18fu.cash`  
- ✅ Metadata-anchored to VALORCHAIN

---

## 🛠 How to Deploy

1. Install OpenZeppelin dependencies:
```bash
npm install @openzeppelin/contracts
```

2. Deploy with Remix or Hardhat using:
```solidity
contract VBLKToken is ERC20, Ownable {
    constructor() ERC20("Valor Blockchain Token", "VBLK") {
        _mint(msg.sender, 100_000_000 * 10 ** decimals());
    }
}
```

3. Verify on Etherscan and register external URL:
```
https://www.18fu.cash
```

---

## 🧩 Contact

Built by: **Donny Adams**  
GitHub: [@DonAdams1969](https://github.com/DonAdams1969)  
Gateway: [www.18fu.cash](https://www.18fu.cash)

> “This isn’t just a token. It’s testimony.”

---
