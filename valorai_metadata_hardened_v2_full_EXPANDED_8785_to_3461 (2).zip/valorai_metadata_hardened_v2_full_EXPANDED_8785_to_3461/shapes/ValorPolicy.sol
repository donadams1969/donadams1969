// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

interface IPolicyOracle {
    function termsHash(bytes32 policyId) external view returns (bytes32);
}

library ValorPolicy {
    function check(bytes32 expected, bytes32 actual) internal pure returns (bool) {
        return expected == actual;
    }
}
