// scripts/deploy.js
const hre = require("hardhat");

async function main() {
  const VBLKToken = await hre.ethers.getContractFactory("VBLKToken");
  const token = await VBLKToken.deploy();

  await token.deployed();

  console.log("VBLKToken deployed to:", token.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
